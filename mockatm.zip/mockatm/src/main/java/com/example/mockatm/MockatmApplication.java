package com.example.mockatm;

import com.example.mockatm.entities.Aid;
import com.example.mockatm.entities.Transaction;
import com.example.mockatm.repositories.TransactionRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;
import com.example.mockatm.AtmRepository;
import com.example.mockatm.repositories.AidRepository;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;



@SpringBootApplication
@Controller
public class MockatmApplication {

	//Repositories for all the Databases we stored
	private final AtmRepository atmRepository;
	private final AidRepository aidRepository;
	private final TransactionRepository transactionRepository;

	//Initialized the Repositories
	public MockatmApplication(AtmRepository atmRepository, AidRepository aidRepository, TransactionRepository transactionRepository){
		this.atmRepository=atmRepository;
		this.aidRepository=aidRepository;
		this.transactionRepository=transactionRepository;
	}

	public static void main(String[] args) {
		SpringApplication.run(MockatmApplication.class, args);
	}

	// Home Page
	// Gets all the transaction from the database
	// Sends the transactions to the html using the model and ThymeLeaf to display it on a table
	// Most of the Methods work similar to this one
	@GetMapping("/")
	public String homePage(Model model) throws IOException {
		// Only Need this Method to fill the Database
		// So if Database empty un comment for one run
		// After one iteration comment it again
		//readJsonTransactionList();
		Iterable<Transaction> transactionsList = this.transactionRepository.findAll();
		model.addAttribute("transactionList", transactionsList);
		model.addAttribute("transaction", new Transaction());
		return "index";
	}
	// If Client sends a search result its Post here
	// Gets all the transactions from the repository
	// Also gets the search result sent from the client called item
	// Compares with each transaction and if it appears add the tranaction to the search results list
	// Item is the String that needs to be filtered
	@PostMapping("/")
	public String search(@ModelAttribute(name="item") String item, Model model) throws JsonProcessingException {
		Iterable<Transaction> totalTransaction = this.transactionRepository.findAll();
		ArrayList<Transaction> filteredTransaction = new ArrayList<Transaction>();
		for(Transaction transaction:totalTransaction){
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(transaction);
			System.out.print(item);
			if(json.contains(item)){
				//System.out.print(atm.country);
				filteredTransaction.add(transaction);
			}
		}
		model.addAttribute("transaction", new Transaction());
		model.addAttribute("transactionList",filteredTransaction);
		return "index";
	}
	@GetMapping("searchDate")
	public String getSearchDate(Model model){
		Iterable<Transaction> transactionsList = this.transactionRepository.findAll();
		model.addAttribute("transactionList", transactionsList);
		model.addAttribute("transaction", new Transaction());
		return "index";
	}

	// If Clients searches date
	// Sends data in the parameter
	// Compares all transactions to dates and sends the correct ones back
	@PostMapping("/searchDate")
	public String searchDate(@ModelAttribute(name="item") String item, Model model) throws JsonProcessingException {
		Iterable<Transaction> totalTransaction = this.transactionRepository.findAll();
		ArrayList<Transaction> filteredTransaction = new ArrayList<Transaction>();
		for(Transaction transaction:totalTransaction){
			if(String.valueOf(transaction.getDevTime()).equals(item)){
				System.out.print(String.valueOf(transaction.getDevTime())+"-");
				System.out.print(item);
				filteredTransaction.add(transaction);
			}
		}
		model.addAttribute("transaction", new Transaction());
		model.addAttribute("transactionList",filteredTransaction);
		return "index";
	}

	@GetMapping("/searchPan")
	public String getSearchPan(Model model){
		Iterable<Transaction> transactionsList = this.transactionRepository.findAll();
		model.addAttribute("transactionList", transactionsList);
		model.addAttribute("transaction", new Transaction());
		return "index";
	}

	// If Clients searches Pan Number
	// Sends data in the parameter
	// Compares all transactions to Pan Number and sends the correct ones back
	@PostMapping("/searchPan")
	public String searchPan(@ModelAttribute(name="item") String item, Model model) throws JsonProcessingException {
		Iterable<Transaction> totalTransaction = this.transactionRepository.findAll();
		ArrayList<Transaction> filteredTransaction = new ArrayList<Transaction>();
		for(Transaction transaction:totalTransaction){
			if(transaction.getCustomerPan().contains(item)){
				filteredTransaction.add(transaction);
			}
		}
		model.addAttribute("transaction", new Transaction());
		model.addAttribute("transactionList",filteredTransaction);
		return "index";
	}

	@GetMapping("searchId")
	public String getSearchId(Model model){
		Iterable<Transaction> transactionsList = this.transactionRepository.findAll();
		model.addAttribute("transactionList", transactionsList);
		model.addAttribute("transaction", new Transaction());
		return "index";
	}
	// This does not work!!
	// If Clients searches Id
	// Sends data in the parameter
	// Compares all transactions to Id Number and sends the correct ones back
	@PostMapping("/searchId")
	public String searchId(@ModelAttribute(name="item") String item, Model model) throws JsonProcessingException {
		Iterable<Transaction> totalTransaction = this.transactionRepository.findAll();
		ArrayList<Transaction> filteredTransaction = new ArrayList<Transaction>();
		for(Transaction transaction:totalTransaction){
			if(transaction.getAtmId().equals(item)){
				filteredTransaction.add(transaction);
			}
		}
		model.addAttribute("transaction", new Transaction());
		model.addAttribute("transactionList",filteredTransaction);
		return "index";
	}

	@GetMapping("searchSerial")
	public String getSearchSerial(Model model){
		Iterable<Transaction> transactionsList = this.transactionRepository.findAll();
		model.addAttribute("transactionList", transactionsList);
		model.addAttribute("transaction", new Transaction());
		return "index";
	}

	// If Clients searches Transaction Serial Number
	// Sends data in the parameter
	// Compares all transactions to Transaction Serial Number and sends the transactions with that serial number
	@PostMapping("/searchSerial")
	public String searchSerial(@ModelAttribute(name="item") String item, Model model) throws JsonProcessingException {
		Iterable<Transaction> totalTransaction = this.transactionRepository.findAll();
		ArrayList<Transaction> filteredTransaction = new ArrayList<Transaction>();
		for(Transaction transaction:totalTransaction){
			if (transaction.getTransactionNumber() != null) {
				if(transaction.getTransactionNumber().equals(item)){
					filteredTransaction.add(transaction);
				}
			}
		}
		model.addAttribute("transaction", new Transaction());
		model.addAttribute("transactionList",filteredTransaction);
		return "index";
	}

	//////////////////////////////////////////////////////////////////////////
	// This stuff not in the required project
	// Left it here  in case of future requirements
	// Not sure if this was required so I left it here
	// They pretty much do the queries given on the website for this assignment

	@ResponseBody
	@GetMapping("/um/test/api/jr/txn/atmlist/v1")
	public Iterable<Atm> getAtms() throws IOException {
		//This is commented
		//In case you need to add the data back into the database again then uncomment
		//readJsonAtm();
		return this.atmRepository.findAll();
	}
	// Reads the atm Json file
	// Puts it into the database
	public void readJsonAtm() throws IOException{
		//read Json File
		File file = ResourceUtils.getFile("classpath:atmlist.json");
		String content = new String(Files.readAllBytes(file.toPath()));
		final ObjectMapper objectMapper = new ObjectMapper();
		Atm[] atms = objectMapper.readValue(content, Atm[].class);
		for(Atm atm:atms){
			this.atmRepository.save(atm);
		}
	}
	@ResponseBody
	@GetMapping("/um/test/api/jr/txn/aidlist/v1")
	public Iterable<Aid> getaidlist() throws IOException{
		//This is commented
		//In case you need to add the data back into the database again then uncomment
		//readJsonAid();
		return this.aidRepository.findAll();
	}
	// Reads the Json Aid file
	// Puts it into a database
	public void readJsonAid() throws IOException{
		//read Json File
		File file = ResourceUtils.getFile("classpath:aidlist.json");
		String content = new String(Files.readAllBytes(file.toPath()));
		final ObjectMapper objectMapper = new ObjectMapper();
		Aid[] aids = objectMapper.readValue(content, Aid[].class);
		for(Aid aid:aids){
			this.aidRepository.save(aid);
		}
	}

	// This method takes the transaction info from the Json file and puts it into a DataBase
	// I used dto objects first before putting the info into my database because alot of the info was useless
	// After creating the Dto Objects I used the necessary variables to put it into an Entity and the database

	public DtoTransaction[] readJsonTransactionList() throws IOException{
		//read Json File
		File file = ResourceUtils.getFile("classpath:atmresult.json");
		String content = new String(Files.readAllBytes(file.toPath()));
		final ObjectMapper objectMapper = new ObjectMapper();
		DtoTransaction[] transactionList = objectMapper.readValue(content, DtoTransaction[].class);
		// Puts all the Required from the DTO into the Transaction object
		// Then saves the Transaction object into the Database
		for(DtoTransaction dto:transactionList){
			Transaction transaction= new Transaction();
			transaction.setDevTime(dto.getDevTime());
			transaction.setAtmId(dto.getAtm().get("txt"));
			transaction.setTransactionNumber(dto.getRef());
			transaction.setCustomerPan(dto.getPan());
			//
			String s="";
			if(dto.getTtp()!=null){
				s=s+dto.getTtp().get("descr")+" | "+"\n";
			}
			if(dto.key!=null){
				for(HashMap<String, String> map:dto.getKey()){
					s = s+map.get("descr")+" | "+"\n";
				}
			}
			if(dto.getHst()!=null){
				s=s+dto.getHst().get("descr")+" | "+"\n";
			}
			transaction.setDescription(s);
			this.transactionRepository.save(transaction);
		}
		return transactionList;
	}

}
