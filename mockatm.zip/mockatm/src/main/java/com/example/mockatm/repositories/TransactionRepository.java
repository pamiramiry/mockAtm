package com.example.mockatm.repositories;

import com.example.mockatm.entities.Transaction;
import org.springframework.data.repository.CrudRepository;

public interface TransactionRepository extends CrudRepository<Transaction, Integer>{
}
