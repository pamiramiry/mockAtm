package com.example.mockatm;

import org.springframework.data.repository.CrudRepository;
import com.example.mockatm.Atm;
import java.util.ArrayList;
import java.util.Optional;

public interface AtmRepository extends CrudRepository<Atm, Integer> {

}
