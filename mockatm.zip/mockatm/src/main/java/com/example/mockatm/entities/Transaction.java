package com.example.mockatm.entities;

import jakarta.persistence.*;
import org.hibernate.annotations.Type;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "TRANSACTION")
public class Transaction {
    @Id
    @GeneratedValue
    Integer id;

    @Column(name = "ATMID")
    String atmId;
    @Column(name = "CUSTOMERPAN")
    String customerPan;
    @Column(name = "DEVTIME")
    Long devTime;
    @Column(name="DESCRIPTION")
    String description;
    @Column(name="TRANSACTIONNUMBER")
    String transactionNumber;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getAtmId() {
        return atmId;
    }

    public void setAtmId(String atmId) {
        this.atmId = atmId;
    }

    public String getCustomerPan() {
        return customerPan;
    }

    public void setCustomerPan(String customerPan) {
        this.customerPan = customerPan;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getDevTime() {
        return devTime;
    }

    public void setDevTime(Long devTime) {
        this.devTime = devTime;
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }
}
