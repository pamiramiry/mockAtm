package com.example.mockatm;

import jakarta.persistence.*;
import org.hibernate.annotations.Type;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="ATM")
public class Atm {
    @Id
    Integer Id;
    @Column(name = "NAME")
    String name;
    @Column(name = "COUNTRY")
    String country;
    @Column(name = "TS")
    Long ts;

    public Integer getId(){
        return this.Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Long getTs() {
        return ts;
    }

    public void setTs(Long ts) {
        this.ts = ts;
    }
}
