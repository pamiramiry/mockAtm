package com.example.mockatm.repositories;

import com.example.mockatm.entities.Aid;
import org.springframework.data.repository.CrudRepository;

public interface AidRepository extends CrudRepository<Aid, Integer> {

}
