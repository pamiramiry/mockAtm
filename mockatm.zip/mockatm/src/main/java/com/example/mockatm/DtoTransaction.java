package com.example.mockatm;

import java.util.HashMap;

public class DtoTransaction {
    HashMap<String, String> atm;
    HashMap<String, String> app;
    HashMap<String, String> hst;
    HashMap<String, String> ttp;
    String pan;
    Long devTime;
    HashMap<String, String>[] key;
    String ref;

    Integer amount;
    Integer amountP;
    Integer amountW;
    Integer amountR;
    Boolean err;

    public Boolean getErr() {
        return err;
    }

    public void setErr(Boolean err) {
        this.err = err;
    }

    public Long getDevTime() {
        return devTime;
    }

    public void setDevTime(Long devTime) {
        this.devTime = devTime;
    }

    public HashMap<String, String> getApp() {
        return app;
    }

    public void setApp(HashMap<String, String> app) {
        this.app = app;
    }

    public HashMap<String, String> getAtm() {
        return atm;
    }

    public void setAtm(HashMap<String, String> atm) {
        this.atm = atm;
    }

    public HashMap<String, String> getHst() {
        return hst;
    }

    public void setHst(HashMap<String, String> hst) {
        this.hst = hst;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public HashMap<String, String>[] getKey() {
        return key;
    }

    public void setKey(HashMap<String, String>[] key) {
        this.key = key;
    }

    public HashMap<String, String> getTtp() {
        return ttp;
    }

    public void setTtp(HashMap<String, String> ttp) {
        this.ttp = ttp;
    }

    public Integer getAmount() {
        return amount;
    }

    public Integer getAmountP() {
        return amountP;
    }

    public Integer getAmountR() {
        return amountR;
    }

    public Integer getAmountW() {
        return amountW;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public void setAmountP(Integer amountP) {
        this.amountP = amountP;
    }

    public void setAmountR(Integer amountR) {
        this.amountR = amountR;
    }

    public void setAmountW(Integer amountW) {
        this.amountW = amountW;
    }
}

