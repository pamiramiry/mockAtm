package com.example.mockatm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockatmApplicationTests {

	@Test
	void contextLoads() {
	}

}
